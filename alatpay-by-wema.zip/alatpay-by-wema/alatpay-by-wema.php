<?php
/*
 * Plugin Name: ALATPay Payment Gateway
 * Plugin URI: https://alatpay.developer.azure-api.net/get-started
 * Description: Safe and Secure payment gateway using Card, Bank Transfer, Bank Account, QR payments, etc on your store.
 * Author: ALATPay by Wema Bank - @dibanga
 * Author URI: https://alatpay.ng
 * Version: 1.0.1
 */
 
add_filter('woocommerce_payment_gateways', 'alatpay_add_gateway_class');
function alatpay_add_gateway_class($gateways)
{
    $gateways[] = 'WC_ALATPay_Gateway';
    return $gateways;
}

add_action('plugins_loaded', 'alat_init_gateway_class');
function alat_init_gateway_class()
{
    class WC_ALATPay_Gateway extends WC_Payment_Gateway
    {
        public function __construct()
        {
            $this->id = 'alatpay_by_wema';
            $this->has_fields = true;
            $this->method_title = 'ALATPay';
            $this->method_description = 'Accept and Process unlimited amount of transactions with ALATPay by Wema Bank';
        
            $this->supports = array(
                'products'
            );
        
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');
            $this->testmode = 'yes' === $this->get_option('testmode');
            $this->subscription_key = $this->testmode ? $this->get_option('test_subscription_key') : $this->get_option('subscription_key');
            $this->business_id = $this->testmode ? $this->get_option('test_business_id') : $this->get_option('business_id');
            $this->url = $this->testmode ? $this->get_option('test_url') : $this->get_option('url');
       
            // This action hook saves the settings
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

            // We need custom JavaScript to obtain a token
            add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title'       => 'Enable/Disable',
                    'label'       => 'Enable ALATPay Gateway',
                    'type'        => 'checkbox',
                    'description' => '',
                    'default'     => 'no'
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'label',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default'     => 'Credit/Debit Card, Bank Transfer, Bank Account and QR',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default'     => 'Pay with your credit/debit card, transfer, wema bank account or scan qr.',
                    'desc_tip'    => false,
                ),
                'testmode' => array(
                    'title'       => 'Test mode',
                    'label'       => 'Enable Test Mode',
                    'type'        => 'checkbox',
                    'description' => 'Place the payment gateway in test mode using test business ID and test subscription API keys.',
                    'default'     => 'yes',
                    'desc_tip'    => true,
                ),
                'test_business_id' => array(
                    'title'       => 'Test Business ID',
                    'type'        => 'text',
                    'default'     => 'cca1e068-2220-49a9-4181-08dafc0c53a0',
                    'description' => 'Please replace with your test business Id (If you have any or use the default ID).',
                    'desc_tip'    => false,
                ),
                'test_subscription_key' => array(
                    'title'       => 'Test Subscription Key (Primary/Secondary)',
                    'type'        => 'text',                    
                    'default'     => '61881500a25647beac10dbf370ee348d',
                    'description' => 'Please replace with your test subscripton key (If you have any or use the default key).',
                    'desc_tip'    => false,
                ),
                'business_id' => array(
                    'title'       => 'Live Business ID',
                    'type'        => 'text',
                    'description' => 'Please replace with your subscripton key',
                ),
                'subscription_key' => array(
                    'title'       => 'Live Subscription Key (Primary/Secondary)',
                    'type'        => 'text',
                    'description' => 'Please replace with your subscripton key',                    
                    
                ),
                'test_url' => array(
                    'title'       => 'Endpoint',
                    'type'        => 'text',                    
                    'default'     => 'https://alatpay-client.azurewebsites.net/js/alatpay.js',
                    'description' => 'To test, <a href="https://alatpay-dev.azurewebsites.net/">Get Started here.</a>',
                ),
                'url' => array(
                    'title'       => 'Live Endpoint',
                    'type'        => 'text',
                    'default'     => 'https://web.alatpay.ng/js/alatpay.js',
                    'description' => 'To go live, <a href="https://alatpay.ng/">Get Started here.</a>',
                )
            );
        }
		
        public function payment_scripts()
        {           
            if (!is_cart() && !is_checkout() && !isset($_GET['pay_for_order'])) {
                return;
            }

            if ('no' === $this->enabled) {
                return;
            }

            if (empty($this->subscription_key) || empty($this->business_id)) {
                echo 'Sorry, an error occurred with the business. Please, fix configuration.';
                return;
            }

            if (!$this->testmode && !is_ssl()) {
                return;
            }

            if (is_checkout()) {
                $ajax_url = admin_url('admin-ajax.php');
                $order_id = WC()->session->get('order_awaiting_payment');

                if ($order_id > 0) {
                    WC()->session->set('order_awaiting_payment', $order_id);
					// WC()->session->set('order_awaiting_payment', $order_awaiting_payment);
                    $order = wc_get_order($order_id);
                    $email = $order->get_billing_email() ?? "";
                    $phone = $order->get_billing_phone()  ?? "";
                    $firstName = $order->get_billing_first_name()  ?? "";
                    $lastName = $order->get_billing_last_name()  ?? "";
                    $currency = get_woocommerce_currency();
                    $amount = $order->get_total();
					
                    wp_enqueue_script('alatpay_checkout', plugin_dir_url(__FILE__).'js/processor.js',array('jquery'),time(), true);
                    // wp_register_script('alatpay_checkout', plugin_dir_url(__FILE__) . 'js/processor.js', array('jquery','js/processor.js'));
                    wp_localize_script(
                        'alatpay_checkout',
                        'alatpay_settings',
                        array(
                            'subscription_key' => $this->subscription_key,
                            'bid' => $this->business_id,
                            'url' => $this->url,
                            'ajax_url' => $ajax_url,
                            'email' => $email,
                            'phone' => $phone,
                            'firstName' => $firstName,
                            'lastName' => $lastName,
                            'currency' => $currency,
                            'amount' => $amount,
                            'order_id' => $order_id,
                            'metadata' =>$order
                        )
                    );
                }
            }
        }

        public function payment_fields()
        {
            if ($this->description) {
                if ($this->testmode) {
                    $this->description .= '<br><br><b>TEST MODE IS ENABLED</b>. No real money will be debited in test mode.</br>
                    You can read more in our <a href="https://alatpay.developer.azure-api.net/get-started">documentation</a>.';
                    $this->description = trim($this->description);
                }
                echo wpautop(wp_kses_post($this->description));
            }
        }

        public function process_payment($order_id)
        {
            global $woocommerce;
            $order = wc_get_order($order_id);
            $response = $_POST['response'];
            if ($response === 'success') {
                $order->save_meta_data();
                $order->update_status('processing', 'Payment processed successfully');
                $order->add_order_note('Payment processed successfully');
                WC()->cart->empty_cart();
                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            }
            return array(
                'result'   => 'failed with an exception'
            );
        }
    }

    add_action('wp_ajax_process_alatpay_payment_callback', 'process_alatpay_payment_callback');
    add_action('wp_ajax_nopriv_process_alatpay_payment_callback', 'process_alatpay_payment_callback');

    function process_alatpay_payment_callback()
    {
        if (isset($_POST['order_id'])) {
            $order_id = $_POST['order_id'];
            global $woocommerce;
            $response = $_POST['response'];

            $gateway = new WC_ALATPay_Gateway();// new instantiation of the alatpay gateway class..
            $payment_result = $gateway->process_payment($order_id);

            if ($payment_result['result'] === 'success') {
                wp_send_json_success(array(
                    'result'   => 'success',
                    'redirect' => $gateway->get_return_url(wc_get_order($order_id))
                ));
            } else {
                wp_send_json_error('Payment processing failed');
            }
        } else {
            wp_send_json_error('Invalid order ID');
        }
    }
}