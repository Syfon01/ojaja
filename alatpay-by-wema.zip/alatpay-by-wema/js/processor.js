
jQuery(document).ready(function($) {
    $('form.checkout').one('click', '#place_order', function(e) {
        e.preventDefault(); // Prevent the default form submission
        
        var alatpayScriptUrl = alatpay_settings.url;
        var subscription_key = alatpay_settings.subscription_key;
        var businessId = alatpay_settings.bid;
        var firstName = alatpay_settings.firstName;
        var lastName = alatpay_settings.lastName;
        var email = alatpay_settings.email;
        var phone = alatpay_settings.phone;
        var metaData =  JSON.stringify(alatpay_settings.metadata);
        
        // Dynamically create a script element
        var scriptElement = document.createElement('script');
        scriptElement.src = alatpayScriptUrl;

        scriptElement.onload = function() {
            Alatpay.setup({
                apiKey: subscription_key, 
                businessId: businessId,
                email: email,
                phone: phone,
                firstName: firstName,
                lastName: lastName,
                metadata: alatpay_settings.order_id, //send order ID as metadata to alatpay options..
                currency: alatpay_settings.currency,
                amount: parseFloat(alatpay_settings.amount), //parsed to accept decimal point values...

                onTransaction: function (response) {
                    console.log("API response is ", response);

                    if(response.data.status === 'completed'){

                        $.ajax({
                            type: 'POST',
                            url: alatpay_settings.ajax_url,
                            data: {
                                action: 'process_alatpay_payment_callback',
                                order_id: alatpay_settings.order_id,
                                response: 'success'
                            },
                            success: function(resp) {
                                console.log(resp);
                                if (resp.success && resp.data.result === 'success') {
                                    $('body').append('<div id="redirecting-notice">Redirecting...</div>');

                                    // Redirect the user to the order received/thank you page
                                    window.location.href = resp.data.redirect;
                                } else {
                                    // Handle the error or display a message to the user
                                    console.log('Payment processing failed');
                                }
                            },
                            error: function(xhr, ajaxOptions, thrownError) {
                                console.log("Oops, an error occurred. Please, retry!");
                            }
                        });
                    }
                },
                
                onClose: function () {
                    amount = 0.00;
					alatpay_settings.amount = 0.00
                    console.log("Payment gateway is closed");
                }
            }).show();
        };
        document.head.appendChild(scriptElement);
    });
});